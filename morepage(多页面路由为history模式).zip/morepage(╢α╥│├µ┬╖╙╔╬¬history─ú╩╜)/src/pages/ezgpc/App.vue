<template>
  <div id="ezgpc">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: "page1"
};
</script>

<style lang="scss" scoped>
#ezgpc {
  // width: 1220px;
  // margin: 0 auto;
}
</style>
